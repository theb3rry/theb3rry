/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SellItems;

import java.util.Scanner;

/**
 * @author tyron
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.print("Iput the number of items ");
        Scanner kb = new Scanner(System.in);
        int size = kb.nextInt();
        double[] items = new double[size];

        int i;
        double total = 0, tax = 0.07;

        for (i = 0; i < items.length; i++) {
            System.out.print("Enter price of item: " + (i + 1) + "");
            items[i] = kb.nextDouble();
            total = total + items[i];

        }
        System.out.print("\nItems breakdown: ");
        for (i = 0; i < items.length; i++) {
            System.out.println(items[i]);

        }

        double totalTax = total * tax;
        System.out.println("Taxes: $%.3f\n" + totalTax);
        System.out.println("Total amount: $%.3f\n" + (total - totalTax));

    }

}
