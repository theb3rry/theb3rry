package dijkstra;

import java.util.*;

// graph node contains vertex, weight and its adjacent vertices
class GraphNode {
    // a vertex
    private Character vertex;
    // edge weight
    private Integer weight = Integer.MAX_VALUE;
    // adjacent vertices
    Map<GraphNode, Integer> adjacentVertices = new HashMap<>();

    public GraphNode(Character v) {
        vertex = v;
    }

    // getter and setter methods
    public Character getVertex() {
        return vertex;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setVertex(Character v) {
        vertex = v;
    }

    public void setWeight(Integer w) {
        weight = w;
    }

    public void addAdjacent(GraphNode vertex, Integer weight) {
        adjacentVertices.put(vertex, weight);
    }

    public Map<GraphNode, Integer> getAdjacentVertices() {
        return adjacentVertices;
    }

    public void setAdjacentVertices(Map<GraphNode, Integer> adj) {
        adjacentVertices = adj;
    }
}

// graph class
class Graph {
    // graph contains set of graph nodes
    private Set<GraphNode> graph = new HashSet<>();
    // list of calculated shortest path
    private List<GraphNode> shortestPath = new LinkedList<>();

    // add a vertex to graph
    public void addVertex(GraphNode vnode) {
        graph.add(vnode);
    }

    // returns list of calculated shortest path using Dijkstra algorithm
    public List<GraphNode> getShortestPath(GraphNode source, GraphNode target) {
        // if source and target are same
        if (source.getVertex().equals(target.getVertex()))
            return null;

        // set weight of vertex source to 0
        // because we are using adjacent vertices weights (edges)
        source.setWeight(0);

        // set of visited vertices during BFS
        Set<GraphNode> visitedVertices = new HashSet<>();
        // set of unvisited vertices during BFS
        Set<GraphNode> unvisitedVertices = new HashSet<>();

        // add source to unvisited
        unvisitedVertices.add(source);

        // continue until all vertices are visited
        while (!unvisitedVertices.isEmpty()) {
            // get minimum weight adjacent vertex
            GraphNode currentVertex = getLowestWeightVertex(unvisitedVertices);
            // remove that from unvisited
            unvisitedVertices.remove(currentVertex);
            // go through its all adjacent vertices
            for (Map.Entry<GraphNode, Integer> adjacencyPair : currentVertex.getAdjacentVertices().entrySet()) {
                GraphNode adjacentVertex = adjacencyPair.getKey();
                Integer edgeWeight = adjacencyPair.getValue();
                // calculate minimum distance between all adjacent vertices and current vertex
                if (!visitedVertices.contains(adjacentVertex)) {
                    calculateMinimumDistance(adjacentVertex, edgeWeight, currentVertex);
                    unvisitedVertices.add(adjacentVertex);
                }
            }
            // add current vertex to visited
            visitedVertices.add(currentVertex);
        }
        if (!containsVertex(target))
            shortestPath.add(target);
        return shortestPath;
    }

    // return vertex node which has lowest weight than other neighbours
    private GraphNode getLowestWeightVertex(Set<GraphNode> unvisitedVertices) {
        GraphNode minWeightNode = null;
        int min = Integer.MAX_VALUE;
        // get all unvisited vertices and their weights
        // and find minimum weight between those
        for (GraphNode vnode : unvisitedVertices) {
            int vWeight = vnode.getWeight();
            if (vWeight < min) {
                min = vWeight;
                minWeightNode = vnode;
            }
        }
        return minWeightNode;
    }

    // compare source and target weights with addding current visited vertex weight
    // if weight is less than target vertex then add it to shortestpath
    private void calculateMinimumDistance(GraphNode target, Integer weight, GraphNode source) {
        Integer sourceWeight = source.getWeight();
        if (sourceWeight + weight < target.getWeight()) {
            target.setWeight(sourceWeight + weight);
            if (!containsVertex(source))
                shortestPath.add(source);
        }
    }

    // returns true if shortestPath contains a given vertex otherwise false
    private boolean containsVertex(GraphNode vnode) {
        for (GraphNode v : shortestPath) {
            if (v.getVertex().equals(vnode.getVertex()))
                return true;
        }
        return false;
    }
}


public class Dijkstra {

    public static void main(String[] args) {
        // create a graph, because the graph is un-directed graph
        // create vertices node a, b, c, d, e, z
        GraphNode a = new GraphNode('a');
        GraphNode b = new GraphNode('b');
        GraphNode c = new GraphNode('c');
        GraphNode d = new GraphNode('d');
        GraphNode e = new GraphNode('e');
        GraphNode z = new GraphNode('z');

        // add adjacents of each vertex according to the given diagram
        a.addAdjacent(b, 4);
        a.addAdjacent(c, 2);

        b.addAdjacent(a, 4);
        b.addAdjacent(c, 1);
        b.addAdjacent(d, 5);

        c.addAdjacent(a, 2);
        c.addAdjacent(b, 1);
        c.addAdjacent(d, 8);
        c.addAdjacent(e, 10);

        d.addAdjacent(b, 5);
        d.addAdjacent(c, 8);
        d.addAdjacent(e, 2);
        d.addAdjacent(z, 6);

        e.addAdjacent(c, 10);
        e.addAdjacent(d, 2);
        e.addAdjacent(z, 5);

        z.addAdjacent(d, 6);
        z.addAdjacent(e, 5);

        // create graph object
        Graph graph = new Graph();

        // get shortest path from graph
        List<GraphNode> shortestPath = graph.getShortestPath(a, z);
        // print shortest path
        System.out.print("The Shortest Path is: ");
        for (GraphNode vnode : shortestPath) {
            System.out.print(vnode.getVertex() + " ");
        }
        System.out.println();

    }
}