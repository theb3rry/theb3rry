package com.example.cs311.ui.dashboard;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class DashboardViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public DashboardViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Create a Project\n"+ "\n" +
                "This page shows you how to start a new Android app project or import an existing project.\n" +
                "1. If you don't have a project opened, Android Studio shows the Welcome screen" +
                "where you can create a new project by clicking Start a new Android Studio project.\n" +
                "2. If you do have a project opened, you start creating a new project by selecting File > New > New Project from the main menu.\n" +
                "3. You should then see the Create New Project wizard." +
                "This wizard lets you choose the type of project you want to create and populates with code and resources to get you started.\n" +
                "\n" +
                "Configure Your New Project\n" +
                "\n" +
                "1. Specify the Name of your project.\n" +
                "2. Specify the Package name. By default, this package name also becomes your application ID, which you can change later.\n" +
                "3. Specify the Save location where you want to locally store your project.\n" +
                "4. Select the Language you want Android Studio to use when creating sample code for your new project. Keep in mind, you are not limited to using only that language creating the project.\n" +
                "5. Select the Minimum API level you want your app to support. When you select a lower API level, your app can rely on fewer modern Android APIs. However, a larger percentage of Android devices are able to run your app. The opposite is true when selecting a higher API level. If you want to see more data to help you decide, click Help me choose.\n" +
                "6. If you want your project to use AndroidX libraries by default, which are improved replacements of the Android Support libraries, check the box next to Use AndroidX artifacts. To learn more, read the AndroidX overview.\n" +
                "7. When you're ready to create your project, click Finish.");
    }

    public LiveData<String> getText() {
        return mText;
    }
}