package com.example.cs311.ui.notifications;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class NotificationsViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public NotificationsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Build and run your app\n" +
                "Android Studio sets up new projects to deploy to the Android Emulator or a connected device with just a few clicks. Once your app is installed, " +
                "you can use Apply Changes to deploy certain code and resource changes without building a new APK.\n" +
                "\n" +
                "To build and run your app, follow these steps:\n" +
                "\n" +
                "1. In the toolbar, select your app from the run configurations drop-down menu.\n" +
                "2. From the target device drop-down menu, select the device that you want to run your app on.\n" +
                "3. Click Run" +
                "Change the run/debug configuration\n" +
                "When you run your app for the first time, Android Studio uses a default run configuration. " +
                "The run configuration specifies whether to deploy your app from an APK or an Android App Bundle, " +
                "the module to run, package to deploy, activity to start, target device, emulator settings, logcat options, and more.\n" +
                "\n" +
                "The default run/debug configuration builds an APK, launches the default project activity, and uses the Select Deployment Target dialog for target device selection. " +
                "If the default settings don't suit your project or module, you can customize the run/debug configuration, or even create a new one, at the project, default, and module levels. " +
                "1. To edit a run/debug configuration, select Run > Edit Configurations.\n" +
                "\n" +
                "Build your project\n" +
                "The Run button builds and deploys your app to a device. \n" +
                "However, to build your app to share or upload to Google Play, you'll need to use one of the options in the Build menu to compile parts or all of your project. " +
                "Before you select any of the build options listed in table 1, make sure you first select the build variant you want to use.");
    }

    public LiveData<String> getText() {
        return mText;
    }
}