package com.example.cs311.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is a guide to setup Android Studio on your local device.\n" +
                "1. Go to https://developer.android.com/studio/install\n" +
                "2. download the correct exe file for your operating system\n" +
                "For Windows users Follow steps below:\n" +
                "1. If you downloaded an .exe file (recommended), double-click to launch it.\n" +
                "2. If you downloaded a .zip file, unpack the ZIP, copy the android-studio folder into your Program Files folder.\n" +
                "3. then open the android-studio > bin folder and launch studio64.exe (for 64-bit machines) or studio.exe (for 32-bit machines).\n" +
                "4. Follow the setup wizard in Android Studio and install any SDK packages that it recommends.\n" +
                "5. You're all set :)\n" +
                "For Mac users follow the steps below:" +
                "1. Launch the Android Studio DMG file.\n" +
                "2. Drag and drop Android Studio into the Applications folder, then launch Android Studio.\n" +
                "3. Select whether you want to import previous Android Studio settings, then click OK.\n" +
                "4. The Android Studio Setup Wizard guides you through the rest of the setup, which includes downloading Android SDK components that are required for development.\n" +
                "For Linux users follow steps below:\n" +
                "\n"+
                "1. Unpack the .zip file you downloaded to an appropriate location for your applications, such as within /usr/local/ for your user profile, or /opt/ for shared users.\n" +
                "2. If you're using a 64-bit version of Linux, make sure you first install the required libraries for 64-bit machines.\n" +
                "\n" +
                "3. To launch Android Studio, open a terminal, navigate to the android-studio/bin/ directory, and execute studio.sh.\n" +
                "4. Select whether you want to import previous Android Studio settings or not, then click OK.\n" +
                "5. The Android Studio Setup Wizard guides you through the rest of the setup, which includes downloading Android SDK components that are required for development.");
    }

    public LiveData<String> getText() {
        return mText;
    }
}