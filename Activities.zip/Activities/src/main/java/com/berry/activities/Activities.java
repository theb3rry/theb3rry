/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.berry.activities;

/**
 * @author tyron
 */


import java.util.Scanner;


public class Activities {

//THIS CODE ALLOWS THE USER TO INPUT A DAY OF THE WEEK AND RECIEVE A SHORT DESCRIPTION OF THAT DATA AS A RETURN VALUE


    public static void main(String[] args) {

        System.out.println("Select the appropriate days: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday.");

        //scanner variable to receive user input

        Scanner kb = new Scanner(System.in);
        String day = kb.nextLine();

        //nested loop to return the user's input value

        if (day.equalsIgnoreCase("Monday")) {
            System.out.println("Monday - Leg day.");
            System.out.println("Complete all reps and sets\n");
        } else if (day.equalsIgnoreCase("Tuesday")) {
            System.out.println("Tuesday - Cardio day.");
            System.out.println("Don't forget to control your breathing!\n");
        } else if (day.equalsIgnoreCase("Wednesday")) {
            System.out.println("Wednesday - Chest day.");
            System.out.println("Don't forget to arch your back!\n");
        } else if (day.equalsIgnoreCase("Thursday")) {
            System.out.println("Thursday - Rest day.");
            System.out.println("REST!\n");
        } else if (day.equalsIgnoreCase("Friday")) {
            System.out.println("Friday - Cardio day.");
            System.out.println("Don't forget to control your breathing!\n");
        } else if (day.equalsIgnoreCase("Saturday")) {
            System.out.println("Saturday - Leg day.");
            System.out.println("Light weight, low reps!\n");
        } else {
            System.out.println("Nothing is scheduled for this day!\n Closing program...");
        }
        kb.close();


    }
}

